create trigger TB_BLOG_TRIGGER
  before insert
  on ASS_BLOG
  for each row
BEGIN
	SELECT ASS_BLOG_SEQ.NEXTVAL INTO :NEW.PK_ID FROM DUAL;
END;
/

