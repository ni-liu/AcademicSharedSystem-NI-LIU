create TYPE BLOG_TABLE AS OBJECT(
	PK_ID int,
	BLOG_TITLE	varchar2(90),
	USER_ID	char(10),
	BLOG_CONTENT	varchar2(256),
	FILE_DOWNLOAD	varchar2(256),
	LAUNCH_TIME	varchar2(50),
	AUTHORITY	smallint,
	NICKNAME varchar2(30),
    COURSE_ID char(10)
);
/

