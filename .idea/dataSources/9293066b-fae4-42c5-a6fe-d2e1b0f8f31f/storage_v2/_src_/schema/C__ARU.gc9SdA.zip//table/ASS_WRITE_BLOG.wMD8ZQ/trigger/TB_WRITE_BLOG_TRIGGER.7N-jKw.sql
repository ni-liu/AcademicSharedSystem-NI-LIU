create trigger TB_WRITE_BLOG_TRIGGER
    before insert
    on ASS_WRITE_BLOG
    for each row
BEGIN
	SELECT ASS_WRITE_BLOG_SEQ.NEXTVAL INTO :NEW.PK_ID FROM DUAL;
END;
/

