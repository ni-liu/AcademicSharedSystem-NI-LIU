create trigger TB_COURSE_EXP_TRIGGER
    before insert
    on ASS_COURSE_EXP
    for each row
BEGIN
	SELECT ASS_COURSE_EXP_SEQ.NEXTVAL INTO :NEW.PK_ID FROM DUAL;
END;
/

