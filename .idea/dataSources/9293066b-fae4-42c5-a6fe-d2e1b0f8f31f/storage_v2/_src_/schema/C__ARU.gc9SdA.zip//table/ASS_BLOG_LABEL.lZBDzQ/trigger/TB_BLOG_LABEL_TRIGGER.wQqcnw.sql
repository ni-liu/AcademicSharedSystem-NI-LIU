create trigger TB_BLOG_LABEL_TRIGGER
    before insert
    on ASS_BLOG_LABEL
    for each row
BEGIN
	SELECT ASS_BLOG_LABEL_SEQ.NEXTVAL INTO :NEW.PK_ID FROM DUAL;
END;
/

